$ErrorActionPreference='Stop'
$repo='https://github.com/dtokurisu-png/rok-3d-test.git'
$zip=Join-Path $PSScriptRoot 'Farolera_Mixamo_14_animaciones.zip'
if (!(Test-Path $zip)) { throw "Falta Farolera_Mixamo_14_animaciones.zip junto a este script." }
if (!(Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git no está instalado o no está en PATH.' }
Add-Type -AssemblyName System.IO.Compression
$archive=[IO.Compression.ZipFile]::OpenRead($zip)
try {
  $names=@($archive.Entries | Where-Object {$_.FullName -match '\.fbx$'})
  if($names.Count -ne 14){throw "Se esperaban 14 FBX y hay $($names.Count)."}
} finally {$archive.Dispose()}
$tmp=Join-Path ([IO.Path]::GetTempPath()) ('rok-3d-animations-'+[guid]::NewGuid().ToString('N'))
try {
  git clone --depth 1 $repo $tmp
  if ($LASTEXITCODE -ne 0) {throw 'No se pudo clonar el repositorio.'}
  $target=Join-Path $tmp 'animations'
  New-Item -ItemType Directory -Force -Path $target | Out-Null
  Copy-Item -LiteralPath $zip -Destination (Join-Path $target 'Farolera_Mixamo_14_animaciones.zip') -Force
  Push-Location $tmp
  try {
    git add -- animations/Farolera_Mixamo_14_animaciones.zip
    git diff --cached --quiet
    if($LASTEXITCODE -eq 0) {Write-Host 'El paquete ya está publicado y no tiene cambios.' -ForegroundColor Green;exit 0}
    git commit -m 'Publish full Farolera Mixamo 14 animation pack for every browser'
    if ($LASTEXITCODE -ne 0) {throw 'No se pudo crear el commit.'}
    git push origin HEAD:main
    if ($LASTEXITCODE -ne 0) {throw 'No se pudo subir a GitHub. Revisa autenticación y cambios remotos.'}
    Write-Host 'Animaciones publicadas en GitHub correctamente.' -ForegroundColor Green
  } finally {Pop-Location}
} finally {if(Test-Path $tmp){Remove-Item -LiteralPath $tmp -Recurse -Force}}
